
# File:    hw5_1.py
# Authors: Mengxin Cao (mengxinc), Xiongyu Chen (xiongyuc)


import numpy as np

# Your code here

def MatrixChainMult(A_chain):
    nmat = len(A_chain)
    matStore = np.array([[(0,0)]*nmat]*nmat)
    for i in range(1, nmat): # iterate column
        for j in range(nmat-i): # iterate sub-diagonal
            pos = i+j
            temp = j
            count = np.inf
            for k in range(j, pos): # (j, pos)
                s1 = matStore[j, k][0] + A_chain[j].shape[0]*A_chain[k].shape[1]*A_chain[pos].shape[1] + matStore[k+1, pos][0]
                if s1 < count:
                    count = s1
                    temp = k
            matStore[j,pos] = [count, temp]

    def get_string(i, j, res):
        if i > j:
            return
        if i == j:
            res += f'A{i+1}'
            return res
        # if i+matStore[i, j][1] == j:
        #     res += '('
        #     for k in range(i,j+1):
        #         res += f'A{k+1}'
        #     res+=')'
        #     return res
        res += '('
        res = get_string(i, matStore[i, j][1], res)
        res = get_string(matStore[i, j][1]+1, j, res)
        res += ')'
        return res


    order1 = get_string(0, nmat-1, '')
    return matStore[0, nmat-1][0], order1[1:-1]


# 0 800 600
# 0  0  200,1
# 0  0  0

# Test cases

print('\n5_1.a:')   # 3 matrices
A_chain_1 = [ np.ones((20,4)), np.ones((4,10)),
              np.ones((10,5)) ]

nops, order = MatrixChainMult(A_chain_1)

print(len(A_chain_1), 'matrices')  
print('Matrix dimensions are:')
for m in range(len(A_chain_1)):
    print('A' + str(m+1) + ':', A_chain_1[m].shape)
                               # A1: (20, 4)
                               # A2: (4, 10)
                               # A3: (10, 5)
  
print('Chain requires', nops, 'operations.')  # 600

print('Ordering is:')
print(order)                   # A1 (A2 A3)


print('\n5_1.b:')   # 6 matrices
A_chain_2 = [ np.ones((10,4)), np.ones((4,20)),
              np.ones((20,8)), np.ones((8,5)),
              np.ones((5,12)), np.ones((12,3))]

nops, order = MatrixChainMult(A_chain_2)
  
print(len(A_chain_2), 'matrices')  
print('Matrix dimensions are:')
for m in range(len(A_chain_2)):
    print('A' + str(m+1) + ':', A_chain_2[m].shape)
  
print('Chain requires', nops, 'operations.')

print('Ordering is:')
print(order)


print('\n5_1.c:')   # 12 matrices
dims = [12, 4, 20, 30, 8, 3, 5, 25, 12, 8, 20, 4, 15]
A_chain_3 = [ np.ones((dims[i],dims[i+1])) for i in range(len(dims)-1) ]

nops, order = MatrixChainMult(A_chain_3)
  
print(len(A_chain_3), 'matrices')  
print('Matrix dimensions are:')
for m in range(len(A_chain_3)):
    print('A' + str(m+1) + ':', A_chain_3[m].shape)
  
print('Chain requires', nops, 'operations.')

print('Ordering is:')
print(order)


print('\n5_1.d:')   # 40 matrices
np.random.seed(4)
dims = [np.random.randint(3, 40) for i in range(41)]
A_chain_4 = [ np.ones((dims[i],dims[i+1])) for i in range(len(dims)-1) ]

nops, order = MatrixChainMult(A_chain_4)
  
print(len(A_chain_4), 'matrices')  
print('Matrix dimensions are:')
for m in range(len(A_chain_4)):
    print('A' + str(m+1) + ':', A_chain_4[m].shape)
  
print('Chain requires', nops, 'operations.')

print('Ordering is:')
print(order)

